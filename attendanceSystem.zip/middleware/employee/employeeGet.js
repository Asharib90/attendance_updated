const employeeGet=(connection)=>(req,res)=>{ 
    const {EmpCode}=req.body

    const filter = {}
    EmpCode? filter['EmpCode']=EmpCode : 0

    connection.then(client => {
    const employers = client.db('Attendance_System').collection('employers')  

    const quotesCollection = employers.find(filter).toArray()
    .then(results => {  
      try {
        res.status(200).send({'users':results});
      } catch (error) {
        res.status(500).send(error);
      }
    })
    .catch(error => {
      console.error(error)
      res.status(404).json({"error":'User is not found'})
    })    
    })
}

module.exports={
  employeeGet:employeeGet
}